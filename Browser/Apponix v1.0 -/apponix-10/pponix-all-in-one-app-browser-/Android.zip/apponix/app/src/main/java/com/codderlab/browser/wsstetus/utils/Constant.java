package com.codderlab.browser.wsstetus.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Constant {

    public static List<File> imageArray = new ArrayList<>();
    public static List<File> videoArray = new ArrayList<>();
    public static List<File> download = new ArrayList<>();

}
