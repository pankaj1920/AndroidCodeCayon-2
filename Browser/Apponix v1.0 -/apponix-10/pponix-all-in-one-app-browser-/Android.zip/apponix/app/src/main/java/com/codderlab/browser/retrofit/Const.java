package com.codderlab.browser.retrofit;

public interface Const {
    public static final String PREF_NAME = "userpref";
    String ISLOGIN = "islogin";

    String HISTORY = "serchhistory";
    String SETTING = "setting";
    String BASE_URL = "base";

    //about us
    String TERMS = "https://aboutus.html";


    //wether data
    String Wether = "http://api.openweathermap.org/data/2.5/";
    String WetherApi = "9e00d08244d528d1638a0021ba80897b";


    //news
    String NewsUrl = "https://free-news.p.rapidapi.com";
    String language = "en";
    String HederKey = "6ac8b5a8e0msh71b8090efb8c66ep1bf2f1jsn9f66aa27e314";


    String FAV = "fav";
    String EMAIL = "email";
    String IMAGE = "img";
    String NAME = "name";
    String BOOKMARK = "bookamrk";


    String isTab = "tab";
    String isMe = "me";



    String ADS = "ads";
    String ADS_Downloded = "adsdownload";
}
