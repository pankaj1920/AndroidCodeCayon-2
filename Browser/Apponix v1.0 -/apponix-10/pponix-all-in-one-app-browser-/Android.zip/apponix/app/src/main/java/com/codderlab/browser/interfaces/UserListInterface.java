package com.codderlab.browser.interfaces;


import com.codderlab.browser.Model.FBStoryModel.NodeModel;
import com.codderlab.browser.Model.story.TrayModel;

public interface UserListInterface {
    void userListClick(int position, TrayModel trayModel);

    void fbUserListClick(int position, NodeModel trayModel);
}
