package com.codderlab.browser.Activity.browser;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.codderlab.browser.R;


public class BrowserMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser_main);
    }
}