package com.codderlab.browser.wsstetus.interfaces;

import java.io.Serializable;

public interface OnClick extends Serializable {

    void position(int position, String type);

}
