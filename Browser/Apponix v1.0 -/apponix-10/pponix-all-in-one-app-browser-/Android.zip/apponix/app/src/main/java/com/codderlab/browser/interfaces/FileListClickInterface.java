package com.codderlab.browser.interfaces;

import java.io.File;

public interface FileListClickInterface {
    void getPosition(int position, File file);
}
