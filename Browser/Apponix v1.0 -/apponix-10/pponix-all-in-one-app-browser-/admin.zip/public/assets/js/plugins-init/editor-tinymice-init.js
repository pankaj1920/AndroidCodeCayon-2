(function($) {
    "use strict"

    tinymce.init({
        selector: '#tinymice_editor'
    });




})(jQuery);